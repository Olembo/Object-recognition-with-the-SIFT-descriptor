import os
import numpy as np
import time
import pickle
from pathlib import Path
import seaborn as sn
import pandas as pd
import matplotlib
import matplotlib.pyplot as plt
import cv2 as cv
from numpy import array
from pathlib import Path
from collections import Counter
import matplotlib.animation as animation
from matplotlib import style



d = 64
k = 3
confusion_dir = 'confusion/'
confusion_mat_dir = 'confusion_matrix/'
storage_dir = 'storage/'
path = 'dataset'

dirs = os.listdir(path)

print('nombre de classes : ',len(dirs))


def train():
    total = 0
    DATAPOINTS = []
    start_time = time.time()
    CLASSES = []
    for idx, obj in enumerate(dirs):
        temp = []
        print('CLASSES [',idx,']=',obj, ' | images samples : ',len(os.listdir(path+'/'+obj+'/train')))
        total +=len(os.listdir(path+'/'+obj+'/train'))
        st_local = time.time()
        doss = os.listdir(path+'/'+obj+'/train')
        CLASSES.append(obj)
        for idx, fic in enumerate(doss):
            sift = cv.xfeatures2d.SIFT_create(d)
            kp1, des1 = sift.detectAndCompute(cv.imread(path+'/'+obj+'/train/'+fic),None)
            temp.append(des1)
            print(fic,'...........................',idx/len((os.listdir(path+'/'+obj+'/train'))))
        DATAPOINTS.append(temp)
    print("---general %s seconds ---| ---local %s seconds ---" % (time.time() - start_time, time.time() - st_local))
    print('image total : ',total)
    print("--- %s seconds ---" % (time.time() - start_time))

    if(not Path(storage_dir+"storage_simple.gt").is_file()):
        os.mkdir(storage_dir)
        os.mknod("storage_simple.gt")
    f = open(storage_dir+"storage_simple.gt", "wb")
    f.truncate(0)
    pickler = pickle.Pickler(f)
    pickler.dump([DATAPOINTS,CLASSES])
    print('okay, saved')
        
train()
confusion_dir = 'confusion/'
confusion_mat_dir = 'confusion_matrix/'
storage_dir = 'storage/'
path = 'dataset'
file = open(storage_dir+"storage_simple.gt", 'rb')
data = pickle.load(file)
varse = data[0]
classes = data[1]

sift = cv.xfeatures2d.SIFT_create(d)



path = 'dataset'
dirs = os.listdir(path)

print('nombre de classes : ',len(dirs))
correct = 0
total = 0
nearest = 2
#start_time = time.time()
CONFUSION = [] 

def test():
    total = 0
    correct = 0
    for idx, obj in enumerate(dirs):
        doss = os.listdir(path+'/'+obj+'/test')
        local_conf = np.zeros(len(classes))
        for idz, fic in enumerate(doss):
            img = cv.imread(path+'/'+obj+'/test/'+fic)
            kp, des = sift.detectAndCompute(img,None)
            FLANN_INDEX_KDTREE = 1
            index_params = dict(algorithm = FLANN_INDEX_KDTREE, trees = 5)
            search_params = dict(checks=128)
            flann = cv.FlannBasedMatcher(index_params,search_params)

            M = []
            if len(des)>nearest:
                total +=1
                for idy,v in enumerate(varse):
                    tmp = []
                    for z in v:
                        c1 = 0
                        matches = flann.knnMatch(z,des,k=nearest)
                        for i,(m,n) in enumerate(matches):
                            if m.distance <0.6*n.distance:
                                c1+=1
                        tmp.append(c1)
                        M.append([idy,c1])
                        
                        #print(M)
                M.sort(key=lambda x: x[1], reverse=True)
                #print(M)
                k_nearest = M[:k]
                print(k_nearest)
                E = []
                for b in k_nearest:
                    E.append(b[0])
                dav = Counter(E)
                pred = dav.most_common(1)[0][0]
                local_conf[pred] +=1
                if classes[pred] == obj:
                    correct +=1
                print('Originale ',obj,' La classe predite est : ',classes[pred])
                print("Dectection de ",fic,' actual correction rate ',round((correct/total)*100,2),'%')
        CONFUSION.append(local_conf)
    #break
    print('Overall result',round((correct/total)*100,2),'%')
    if(not Path(confusion_dir+"confusion_simple.gt").is_file()):
        os.mkdir(confusion_dir)
        os.mknod("confusion_simple.gt")
    f = open(confusion_dir+"confusion_simple.gt", "wb")
    f.truncate(0)
    pickler = pickle.Pickler(f)
    pickler.dump(CONFUSION)
    
test()

def confusion():
    confusion_dir = 'confusion/'
    confusion_mat_dir = 'confusion_matrix/'
    storage_dir = 'storage/'
    path = 'dataset'
    f = open(storage_dir+"storage_simple.gt", 'rb')
    file = open(confusion_dir+"confusion_simple.gt", 'rb')
    data = pickle.load(file)
    #print(data)
    da = pickle.load(f)
    classes = da[1]
    a = list(range(len(classes)))
    df_cm = pd.DataFrame(data, index = classes,
	                  columns = classes)
    plt.figure(figsize = (10,7))
    sn.heatmap(df_cm, xticklabels=True, yticklabels=True)
    matplotlib.rc('xtick', labelsize=3)
    matplotlib.rc('ytick', labelsize=3)
    plt.xticks(fontsize=5,rotation=90)
    plt.yticks(fontsize=5,rotation=0)
    plt.show()

confusion()
